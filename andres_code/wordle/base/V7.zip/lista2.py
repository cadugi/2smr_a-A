nombres2 = ["juan", "maria", "antonio", "ana", "manuel", "isabel", "david", "carmen", "jose", "laura", "francisco", "marta", "luis", "sofia", "pedro", "elena", "javier", "paula", "carlos", "teresa", "miguel", "raquel", "angel", "silvia", "rafael", "patricia", "alejandro", "beatriz", "pablo", "nuria", "jose luis", "natalia", "alberto", "monica", "fernando", "victoria", "diego", "rosa", "manuela", "joaquin", "marina", "gabriel", "eva", "andres", "lucia", "alvaro", "lourdes", "ivan", "mireia"]



