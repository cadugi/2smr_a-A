var edad = prompt('cuantos años tienes');

        if (edad >= 18) 
        {

                alert ('pa dentro papi')
                alert ('preparate para las cosas mas cochinas que veras en tu vida guarrete 🔥🔥🔥')
                document.write ('<img src=agustino.jpg>')

        }
        
        else
        { 
        alert ('si no tiene los 18... a tu casa, a ver pocoyó');
        alert ('PATO!!!')
        document.write ('<img src=kid.jpg>')

        }
