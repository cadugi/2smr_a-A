var numero = 69
var intentos = 0
var pregunta = prompt('¿Quieres jugar a un juego?\n')

if (pregunta == 'si') {
    alert('¡Muy bien empecemos!\n')
    alert('Tienes que adivinar un número que yo he elegido en caso de no adivinarlo pierdes.\n')
    alert('Empecemos (es del 0 al 100):\n')

    while (intentos < 3) {
        var pregunta2 = parseInt(prompt('Introduce tu número'))
        intentos++

        if (pregunta2 < numero) {
            alert('Fallaste brother, es más grande. Suerte a la próxima (por cierto, mira detrás de ti)\n')
        } else if (pregunta2 > numero) {
            alert('Casi, pero es más pequeño (estoy detrás tuya)\n')
        } else if (pregunta2 === numero) {
            alert('Correcto, no sabes como me gusta el 69 🥵\n')
            document.write ('<img src="saw-feliz.jpg">')
            break
        }
       

        if (intentos === 3) {
            alert('Lo siento, has perdido. El número era el ' + numero + ' has puesto triste a saw :(')
            document.write ('<img src="saw-triste.jpg">')
        }
        
    }

} else if (pregunta == 'trucos') {
    alert ('jeje le sabes')
    var trucos = prompt ('introduce el numero que quieres que sea la respuesta correcta')
    var numero2 = parseInt(trucos)
    alert('¡Muy bien empecemos!\n')
    alert('Tienes que adivinar un número que yo he elegido en caso de no adivinarlo pierdes.\n')
    alert('Empecemos (es del 0 al 100):\n')

    while (intentos < 3) {
        var pregunta2 = parseInt(prompt('Introduce tu número'))
        intentos++

        if (pregunta2 < numero2) {
            alert('Fallaste brother, es más grande. Suerte a la próxima (por cierto, mira detrás de ti)\n')
        } else if (pregunta2 > numero2) {
            alert('Casi, pero es más pequeño (estoy detrás tuya)\n')
        } else if (pregunta2 === numero2) {
            alert('Correcto, no sabes como me gusta el ' + numero2 + ' 🥵')
            document.write ('<img src="saw-feliz.jpg">')
            break
        }
       

        if (intentos === 3) {
            alert('Lo siento, has perdido. El número era el ' + numero + ' has puesto triste a saw :(')
            document.write ('<img src="saw-triste.jpg">')
        }
        
    }

} 


else {
    alert('Tú sabrás pringado\n')
    document.write ('<img src=fuck-u.jpg>')
}

